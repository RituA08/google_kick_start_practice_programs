"""
-------------------------------------------------------
[Alien Generator - Kick Start Round C]
-------------------------------------------------------
Author:  Ritu Ataliya
__updated__ = "2021-07-10"
-------------------------------------------------------
"""


def gold(g):
    
    p = 0
    k = 1
    bars = k 
    count = 1
    
    while k <= g:
    
        for _ in range(1, g + 1): 
            
            hold = (k + count)   
            bars = bars + hold    
            
            if bars == g:
                p = p + 1
            else:
                count += 1
            
        k += 1
        count = 0 
        bars = 0 
        
    return p


p = gold(201)
print(p)

# include these lines if entering input from kick start 
# for case in range(1,int(input())+1):
    # n=int(input())
    # p = gold(n)
    # print('Case #{}: {}'.format(case, p))
